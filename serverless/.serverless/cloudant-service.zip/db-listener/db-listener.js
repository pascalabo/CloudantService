function main(data) {
    if(data._id) {
      console.log("New record created: ID:" + data._id + " - Name:" + data.name + " - Email:" + data.email);
    } else {
      console.log("No document received");
    }
  }
  
exports.main = main;