function main(params) {
    return {
      params: {
        include_docs: true
      }
    };
  }

exports.main = main;